
        <!-- Javascript -->
        <script src="<?= base_url()?>assets/js/jquery-1.11.1.min.js"></script>
        <script src="<?= base_url()?>assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?= base_url()?>assets/js/jquery.backstretch.min.js"></script>
        <script src="<?= base_url()?>assets/js/scripts.js"></script>
        
    

    </body>

</html>